%Trabajo practico N° 3: definición del robot

clc, clear, close all

%definimos matriz DH

% dh = [tita d a alfa sigma]

dh = [ 0    0.290   0      -pi/2   0;
       0    0       0.270   0      0;
       0    0       0.070  -pi/2   0;
       0    0.302   0       pi/2   0;
       0    0       0      -pi/2   0;
       0    0.072   0       0      0 ];



R1 = SerialLink(dh,'name','ABB IRB120 SC #1');
R2 = SerialLink(dh, 'name', 'ABB IRB120 SC #2');
R1.qlim = deg2rad([ -165  165;
                   -110  110;
                   -110  70;
                   -160  160;
                   -120  120;
                   -400  400 ]);
R2.qlim = R1.qlim;
R1.offset = [0, -pi/2, 0, 0, 0, 0];
R2.offset = R1.offset;
robots = {R1, R2};
limx = 1.3;
limy = 1.3;
limz = 1.3;
workspace = [-limx limx -limy limy 0 limz];

